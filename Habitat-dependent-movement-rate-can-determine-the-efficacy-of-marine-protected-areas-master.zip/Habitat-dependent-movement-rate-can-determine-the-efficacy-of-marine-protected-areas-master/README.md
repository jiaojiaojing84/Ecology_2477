# The code for the publication "Habitat-dependent movement rate can determine the efficacy of marine protected areas"
All the codes about the six figures in main text and seven figures in appendix are labelled as "Fig." plus "#number". Figures in appendix have "S" before the number.
